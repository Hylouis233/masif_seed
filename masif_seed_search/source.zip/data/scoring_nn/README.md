## IPA scoring - run directory 

This directory has the scripts to score the Interface post-alignment neural network. This code needs improvements as it is not very robust.
