This are the weights used for the seed benchmark. 
