This are the weights actually used for masif-seed (i.e. not for the benchmark.) 
